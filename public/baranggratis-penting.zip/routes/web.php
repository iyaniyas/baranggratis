<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BarangController;

Route::get('/barang', [BarangController::class, 'index'])->name('barang.index');
Route::get('/barang/create', [BarangController::class, 'create'])->name('barang.create');
Route::post('/barang', [BarangController::class, 'store'])->name('barang.store');
//fitur Show
Route::get('/barang/{id}', [BarangController::class, 'show'])->name('barang.show');
//fitur edit barang
Route::get('/barang/{id}/edit', [BarangController::class, 'edit'])->name('barang.edit');
Route::post('/barang/{id}', [BarangController::class, 'update'])->name('barang.update');
//status barang sudah diambil
Route::post('/barang/{id}/status', [BarangController::class, 'updateStatus'])->name('barang.updateStatus');
//delete barang
Route::post('/barang/{id}/delete', [BarangController::class, 'destroy'])->name('barang.destroy');
//tambah barang
Route::get('/barang/create', [BarangController::class, 'create'])->name('barang.create');
Route::post('/barang/create', [BarangController::class, 'store'])->name('barang.store');
//routes ke index
Route::get('/', [BarangController::class, 'index'])->name('beranda');
