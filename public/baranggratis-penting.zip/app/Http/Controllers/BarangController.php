<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Barang;
use App\Models\Kategori;
use App\Models\Lokasi;

class BarangController extends Controller
{
    public function index(Request $request)
    {
        $query = Barang::with(['kategori', 'lokasi']);

        if ($request->filled('q')) {
            $query->where('judul', 'like', '%' . $request->q . '%');
        }

        if ($request->filled('kategori')) {
            $query->where('kategori_id', $request->kategori);
        }

        if ($request->filled('lokasi')) {
            $query->where('lokasi_id', $request->lokasi);
        }

        if ($request->filled('status')) {
            $query->where('diambil', $request->status === 'diambil');
        }

        $barangList = $query->latest()->paginate(9);

        return view('beranda', [
            'barangList' => $barangList,
            'kategoriList' => Kategori::all(),
            'lokasiList' => Lokasi::all(),
        ]);
    }

    // Tampilkan form tambah barang
    public function create()
    {
        return view('barang.create', [
            'kategoriList' => Kategori::all(),
            'lokasiList' => Lokasi::all(),
        ]);
    }

    // Proses simpan barang baru
    public function store(Request $request)
    {
        $request->validate([
            'judul' => 'required|max:255',
            'deskripsi' => 'required',
            'kategori_id' => 'required|exists:kategoris,id',
            'lokasi_id' => 'required|exists:lokasis,id',
        ]);

        Barang::create([
            'judul' => $request->judul,
            'deskripsi' => $request->deskripsi,
            'kategori_id' => $request->kategori_id,
            'lokasi_id' => $request->lokasi_id,
            'diambil' => 0,
        ]);

        return redirect()->route('beranda')->with('success', 'Barang berhasil ditambahkan!');
    }
}

