<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>BarangGratis.com</title>

  <!-- Bootstrap 5 CSS via CDN -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

  <!-- Dark Theme Custom Style -->
  <style>
    body {
      background-color: #121212;
      color: #e0e0e0;
      font-family: system-ui, sans-serif;
    }

    .navbar, footer {
      background-color: #1f1f1f;
    }

    .form-control, .form-select {
      background-color: #2b2b2b !important;
      color: white !important;
      border-color: #444 !important;
    }

    .form-control::placeholder {
      color: #aaa !important;
    }

    .card {
      background-color: #1e1e1e;
      border: 1px solid #333;
      color: #e0e0e0;
    }

    .card-footer {
      background-color: #1f1f1f;
      color: #aaa;
    }

    .text-muted {
      color: #aaa !important;
    }

    .text-light {
      color: #e0e0e0 !important;
    }

    a {
      color: #4dabf7;
      text-decoration: none;
    }

    .btn-primary {
      background-color: #0d6efd;
      border-color: #0d6efd;
      color: #fff;
    }

    .btn-primary:hover {
      background-color: #0b5ed7;
    }
  </style>
</head>
<body>

  <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark px-3 mb-4">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="{{ url('/') }}">BarangGratis.com</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarContent"
                    aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse justify-content-end" id="navbarContent">
                <!-- Tombol Tambah Barang di kanan -->
                <a href="{{ route('barang.create') }}" class="btn btn-primary ms-auto">
                    + Tambah Barang
                </a>
            </div>
        </div>
    </nav>

  <!-- Konten -->
  <main class="container mb-5">
    @yield('content')
  </main>

  <!-- Footer -->
  <footer class="text-center py-3 text-light">
    &copy; {{ date('Y') }} BarangGratis.com - Dibuat oleh Om Agus
  </footer>

</body>
</html>

