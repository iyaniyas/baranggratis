@extends('layouts.app')

@section('content')
<div class="container">
    <h2>Daftar Barang Gratis</h2>
    <a href="{{ route('barang.create') }}">Tambah Barang</a>
    <ul>
       @foreach($barangs as $barang)
<li>
   <a href="{{ route('barang.show', $barang->id) }}">
        <b>{{ $barang->judul }}</b>
   </a>
   ({{ $barang->kategori->nama ?? '-' }}) <br>
   {{ $barang->deskripsi }} <br>
   @if($barang->gambar)
        <img src="{{ asset('storage/'.$barang->gambar) }}" width="120">
   @endif
   <br>
   @if($barang->status === 'tersedia')
        <form action="{{ route('barang.updateStatus', $barang->id) }}" method="POST" style="display:inline;">
            @csrf
            <input type="hidden" name="status" value="sudah diambil">
            <button type="submit" onclick="return confirm('Yakin ingin mengubah status jadi sudah diambil?')">Tandai Sudah Diambil</button>
        </form>
   @else
        <span style="color:red;font-weight:bold;">Sudah Diambil</span>
   @endif
   <br>
   Lokasi: {{ $barang->lokasi->nama ?? '-' }} | Status: {{ $barang->status }}
   <a href="{{ route('barang.edit', $barang->id) }}">Edit</a>
   <form action="{{ route('barang.destroy', $barang->id) }}" method="POST" style="display:inline;">
        @csrf
        <button type="submit" onclick="return confirm('Yakin mau hapus barang ini?')">Hapus</button>
   </form>
</li>
@endforeach

    </ul>
</div>
@endsection

